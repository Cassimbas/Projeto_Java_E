package model;

import java.sql.Connection;

import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;

public class DAO {
	// Parametros de conex�o
	private String driver="com.mysql.cj.jdbc.Driver";
	private String url="jdbc:mysql://127.0.0.1:3306/dbconsulmed?useTimezone=true&serverTimezone=UTC";
	private String user="root";
	private String password="";
	
	// Conex�o
	private Connection conectar() {
		Connection con = null;
		try {
			Class.forName(driver);
			con =DriverManager.getConnection(url, user, password);
			return con;
			
		} catch (Exception e) {
			// TODO: handle exception
			System.out.println(e);
			return null;
		}
	}
	
	public void inserirPaciente(JavaBeans paciente) {
		String SQLinsert = "insert into pacientes(nome,fone,email,numcard,acomodacao,obs) values (?,?,?,?,?,?);";
		
			try {
				Connection con = conectar();
				
				// Preparar a Query
				PreparedStatement pst = con.prepareStatement(SQLinsert);
				
				// Substituir as ?
				pst.setString(1, paciente.getNome());
				pst.setString(2, paciente.getFone());
				pst.setString(3, paciente.getEmail());
				pst.setString(4, paciente.getNumcard());
				pst.setString(5, paciente.getAcomodacao());
				pst.setString(6, paciente.getObsPath());
				
				//Executar SQL
				pst.executeUpdate();
				
				//Encerrar a concex�ocon.close();
				con.close();
				
			} catch (Exception e) {
				// TODO: handle exception
				System.out.println(e);
			}
	}
	//CRUD READ
	public ArrayList<JavaBeans> listaPacientes(){
		ArrayList<JavaBeans> paciente = new ArrayList<JavaBeans>();
		String sqlRead = "select * from pacientes order by nome";
		
		try {
			Connection con = conectar();
			//Preparar a query
			PreparedStatement pst = con.prepareStatement(sqlRead);
			ResultSet rs = pst.executeQuery();
			while (rs.next() ) {
				String idcon = rs.getString(1);
				String nome = rs.getString(2);
				String fone = rs.getString(3);
				String email = rs.getString(4);
				String numcard = rs.getString(5);
				String acomodacao = rs.getString(6);
				
				//Enviando a Matriz
				paciente.add(new JavaBeans(idcon,nome,fone,email,numcard,acomodacao));
			}
			con.close();
			return paciente;
			
		} catch (Exception e) {
			// TODO: handle exception
			System.out.println(e);
			return null;
		}
	}
	
	/* CRUD Select */
	public void selecionarPaciente(JavaBeans paciente) {
		String sqlSelect = "select * from pacientes where idcon=?";
		try {
			Connection con = conectar();
			//Preparar a query
			PreparedStatement pst = con.prepareStatement(sqlSelect);
			// Substituir os par�mentros 
			pst.setString(1, paciente.getIdcon());
			//Executar SQL
			ResultSet rs = pst.executeQuery();
			//Enquato houver pacientes
			while (rs.next()) {
				// Recebendo do banco
				// System.out.prinln(rs.getNString(2));
				paciente.setIdcon(rs.getString(1));
				paciente.setNome(rs.getString(2));
				paciente.setFone(rs.getString(3));
				paciente.setEmail(rs.getString(4));
				paciente.setNumcard(rs.getString(5));
				paciente.setAcomodacao(rs.getString(6));
				
			}
			//encerrar conex�o
			con.close();
			}catch (Exception e) {
				// TODO: handle exception
				System.out.println(e);
		}
	}
	
	/*
	public void testeConexao() {
		try {
			Connection con=conectar();
			System.out.println(con);
			con.close();			
		} catch (Exception e) {
			// TODO: handle exception
			System.out.println(e);
			
		}
	}*/
	
	/* CRUD Update */
	public void alterarPaciente(JavaBeans paciente) {
		String sqlUpdate = "update pacientes set nome=?,fone=?,email=?,numcard=?,acomodacao=? where idcon=?";
		try {
			Connection con = conectar();
			//Preparar a query
			PreparedStatement pst = con.prepareStatement(sqlUpdate);
			// Substituir os par�mentros 
				pst.setString(1, paciente.getNome());
				pst.setString(2, paciente.getFone());
				pst.setString(3, paciente.getEmail());
				pst.setString(4, paciente.getNumcard());
				pst.setString(5, paciente.getAcomodacao());
				pst.setString(6, paciente.getIdcon());
		
			//executar SQL
		pst.executeUpdate();
			// encerrar conex�o
			con.close();
	} catch (Exception e) {
				// TODO: handle exception
				System.out.println(e);
		}
	}
	
	/* CRUD delete*/
	public void deletarPaciente(JavaBeans paciente) {
		String delete = "delete from pacientes where idcon=?";
		try {
			Connection con = conectar();
			PreparedStatement pst = con.prepareStatement(delete);
			pst.setString(1, paciente.getIdcon());
			pst.executeUpdate();
			con.close();
		}catch (Exception e) {
			System.out.println(e);
		}
	}
}
