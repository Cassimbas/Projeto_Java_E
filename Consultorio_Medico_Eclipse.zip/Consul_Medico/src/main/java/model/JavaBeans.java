package model;

public class JavaBeans {
	private String idcon;
	private String nome;
	private String fone;
	private String email;
	private String numcard;
	private String acomodacao;
	private String obsPath;	
	
	
	public JavaBeans() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	public JavaBeans(String idcon, String nome, String fone, String email, String numcard, String acomodacao, String obsPath) {
		super();
		this.idcon = idcon;
		this.nome = nome;
		this.fone = fone;
		this.email = email;
		this.numcard = numcard;
		this.acomodacao = acomodacao;
		this.obsPath = obsPath;
}
	
	public JavaBeans(String idcon, String nome, String fone, String email, String numcard, String acomodacao) {
		super();
		this.idcon = idcon;
		this.nome = nome;
		this.fone = fone;
		this.email = email;
		this.numcard = numcard;
		this.acomodacao = acomodacao;
		
	}
	

	public String getIdcon() {
		return idcon;
	}
	public void setIdcon(String idcon) {
		this.idcon = idcon;
	}
	public String getNome() {
		return nome;
	}
	public void setNome(String nome) {
		this.nome = nome;
	}
	public String getFone() {
		return fone;
	}
	public void setFone(String fone) {
		this.fone = fone;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getNumcard() {
		return numcard;
	}
	public void setNumcard(String numcard) {
		this.numcard = numcard;
	}
	public String getAcomodacao() {
		return acomodacao;
	}
	public void setAcomodacao(String acomodacao) {
		this.acomodacao = acomodacao;
	}

	public String getObsPath() {
		return "LOAD_FILE(" + this.obsPath +")";
	}

	public void setObsPath(String obsPath) {
		this.obsPath = obsPath;
	}
	
		
}
