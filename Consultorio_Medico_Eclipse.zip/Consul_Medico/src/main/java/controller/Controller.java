package controller;

import java.io.IOException;

import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import model.DAO;
import model.JavaBeans;

/**
 * Servlet implementation class Controller
 */
@WebServlet(urlPatterns = { "/Controller", "/main", "/inserir", "/select", "/update", "/delete" })
public class Controller extends HttpServlet {
	private static final long serialVersionUID = 1L;

	DAO dao = new DAO();
	JavaBeans paciente = new JavaBeans();

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public Controller() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
		// Teste e Conex�o
		// DAO dao = new DAO();
		// dao.testeConexao();
		String action = request.getServletPath();
		System.out.println(action);
		if (action.equals("/main")) {
			paciente(request, response);
		} else if (action.equals("/inserir")) {
			novoPaciente(request, response);
		} else if (action.equals("/select")) {
			listarPaciente(request, response);
		} else if (action.equals("/update")) {
			editarPaciente(request, response);
		} else if (action.equals("/delete")) {
			removerPaciente(request, response);
		} else
			response.sendRedirect("index.html");
	}

	protected void paciente(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// response.sendRedirect("agenda.jsp");
		// Receber dados da int�ncia JavaBeans
		ArrayList<JavaBeans> lista = dao.listaPacientes();
		// teste
		/*
		 * for (int i = 0; i < lista.size(); i++) {
		 * System.out.println(lista.get(i).getIdcon());
		 * System.out.println(lista.get(i).getNome());
		 * System.out.println(lista.get(i).getFone());
		 * System.out.println(lista.get(i).getEmail());
		 * System.out.println(lista.get(i).getNumcard());
		 * System.out.println(lista.get(i).getAcomodacao()); }
		 */

		// M�todo de importar os dados para visualiza��o
		request.setAttribute("pacientes", lista);
		RequestDispatcher rd = request.getRequestDispatcher("agenda.jsp");
		rd.forward(request, response);

	}

	protected void novoPaciente(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// System.out.println(request.getParameter("nome"));
		// System.out.println(request.getParameter("fone"));
		// System.out.println(request.getParameter("email"));
		// System.out.println(request.getParameter("numcard"));
		// System.out.println(request.getParameter("acomodacao"));

		this.paciente.setNome(request.getParameter("nome"));
		this.paciente.setFone(request.getParameter("fone"));
		this.paciente.setEmail(request.getParameter("email"));
		this.paciente.setNumcard(request.getParameter("numcard"));
		this.paciente.setAcomodacao(request.getParameter("acomodacao"));
		this.paciente.setObsPath(request.getParameter("obsPath"));
		// "C:/java/testehospital_2.png"

		dao.inserirPaciente(paciente);

		response.sendRedirect("main");
	}

	protected void listarPaciente(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// Recebe o par�metro idcon
		String idcon = request.getParameter("idcon");
		// Testa o envio do parametro
		System.out.println(idcon);
		// Configura o parametro no objeto
		this.paciente.setIdcon(idcon);
		// Selecionar o contato
		this.dao.selecionarPaciente(paciente);
		// Teste
		/*
		 * System.out.println(contato.getIdcon());
		 * System.out.println(contato.getNome()); System.out.println(contato.getFone());
		 * System.out.println(contato.getEmail());
		 * System.out.println(contato.getNumcard());
		 * System.out.println(contato.getAcomodacao());
		 */
		request.setAttribute("idcon", paciente.getIdcon());
		request.setAttribute("nome", paciente.getNome());
		request.setAttribute("fone", paciente.getFone());
		request.setAttribute("email", paciente.getEmail());
		request.setAttribute("numcard", paciente.getNumcard());
		request.setAttribute("acomodacao", paciente.getAcomodacao());
		RequestDispatcher rd = request.getRequestDispatcher("editar.jsp");
		rd.forward(request, response);
	}

	protected void editarPaciente(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		this.paciente.setIdcon(request.getParameter("idcon"));
		this.paciente.setNome(request.getParameter("nome"));
		this.paciente.setFone(request.getParameter("fone"));
		this.paciente.setEmail(request.getParameter("email"));
		this.paciente.setNumcard(request.getParameter("numcard"));
		this.paciente.setAcomodacao(request.getParameter("acomodacao"));

		this.dao.alterarPaciente(this.paciente);
		response.sendRedirect("main");
	}

	// Remover um Contato
	protected void removerPaciente(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String idcon = request.getParameter("idcon");
		// Recebimento do Id do paciente a ser excluido
		System.out.println(idcon);
		// setar a vari�vel idcon JavaBeans
		paciente.setIdcon(idcon);
		// Executar o m�todo deletarPaciente (DAO) passando o objeto paciente
		dao.deletarPaciente(paciente);
		// Redirecionar para o documento agenda.jsp (Atualizando as altera��es)
		response.sendRedirect("main");
	}

}
